import {
  ServiceType,
  Environment,
  ServiceStatus,
  EdgeType,
} from '../types';
import type {
  ServiceNode,
  ServiceEdge,
  GraphData,
} from '../types';

// ─── Nodes ──────────────────────────────────────────────────────────────────

const nodes: ServiceNode[] = [
  // Layer 0: UI Services
  {
    id: 'ui-trading',
    label: 'Trading Dashboard',
    serviceType: ServiceType.UI,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Frontend Team', latency: '45ms', throughput: '1.2k rps', version: '3.8.1', port: 3000 },
    layer: 0,
  },
  {
    id: 'ui-risk',
    label: 'Risk Console',
    serviceType: ServiceType.UI,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Frontend Team', latency: '52ms', throughput: '800 rps', version: '2.4.0', port: 3001 },
    layer: 0,
  },
  {
    id: 'ui-ops',
    label: 'Ops Portal',
    serviceType: ServiceType.UI,
    environment: Environment.Prod,
    status: ServiceStatus.Warning,
    metadata: { owner: 'Platform Team', latency: '78ms', throughput: '400 rps', version: '1.9.2', port: 3002 },
    layer: 0,
  },
  {
    id: 'ui-analytics',
    label: 'Analytics Hub',
    serviceType: ServiceType.UI,
    environment: Environment.QA,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Data Viz Team', latency: '60ms', throughput: '600 rps', version: '1.2.0', port: 3003 },
    layer: 0,
  },

  // Layer 1: API Gateways
  {
    id: 'gw-main',
    label: 'Main API Gateway',
    serviceType: ServiceType.APIGateway,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Platform Team', latency: '12ms', throughput: '15k rps', version: '5.2.0', port: 8080 },
    layer: 1,
  },
  {
    id: 'gw-auth',
    label: 'Auth Gateway',
    serviceType: ServiceType.APIGateway,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Security Team', latency: '8ms', throughput: '20k rps', version: '3.1.0', port: 8081 },
    layer: 1,
  },
  {
    id: 'gw-data',
    label: 'Data API Gateway',
    serviceType: ServiceType.APIGateway,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Platform Team', latency: '15ms', throughput: '10k rps', version: '2.5.1', port: 8082 },
    layer: 1,
  },

  // Layer 2: Microservices
  {
    id: 'svc-pricing',
    label: 'Pricing Service',
    serviceType: ServiceType.Microservice,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Pricing Team', latency: '25ms', throughput: '8k rps', version: '4.1.3', port: 9001 },
    layer: 2,
  },
  {
    id: 'svc-booking',
    label: 'Booking Service',
    serviceType: ServiceType.Microservice,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Trading Team', latency: '35ms', throughput: '5k rps', version: '3.7.2', port: 9002 },
    layer: 2,
  },
  {
    id: 'svc-counterparty',
    label: 'Counterparty Service',
    serviceType: ServiceType.Microservice,
    environment: Environment.Prod,
    status: ServiceStatus.Warning,
    metadata: { owner: 'Onboarding Team', latency: '42ms', throughput: '3k rps', version: '2.9.0', port: 9003 },
    layer: 2,
  },
  {
    id: 'svc-risk-calc',
    label: 'Risk Calculator',
    serviceType: ServiceType.Microservice,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Risk Team', latency: '120ms', throughput: '2k rps', version: '5.0.1', port: 9004 },
    layer: 2,
  },
  {
    id: 'svc-compliance',
    label: 'Compliance Engine',
    serviceType: ServiceType.Microservice,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Compliance Team', latency: '55ms', throughput: '4k rps', version: '3.3.0', port: 9005 },
    layer: 2,
  },
  {
    id: 'svc-notification',
    label: 'Notification Service',
    serviceType: ServiceType.Microservice,
    environment: Environment.Prod,
    status: ServiceStatus.Down,
    metadata: { owner: 'Platform Team', latency: '—', throughput: '0 rps', version: '2.1.4', port: 9006 },
    layer: 2,
  },
  {
    id: 'svc-settlement',
    label: 'Settlement Service',
    serviceType: ServiceType.Microservice,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Post-Trade Team', latency: '65ms', throughput: '1.5k rps', version: '4.0.0', port: 9007 },
    layer: 2,
  },
  {
    id: 'svc-market-data',
    label: 'Market Data Service',
    serviceType: ServiceType.Microservice,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Data Team', latency: '5ms', throughput: '25k rps', version: '6.2.0', port: 9008 },
    layer: 2,
  },
  {
    id: 'svc-audit',
    label: 'Audit Trail Service',
    serviceType: ServiceType.Microservice,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Compliance Team', latency: '30ms', throughput: '6k rps', version: '2.0.3', port: 9009 },
    layer: 2,
  },

  // Layer 3: Kafka / Streaming
  {
    id: 'kafka-orders',
    label: 'Order Events',
    serviceType: ServiceType.Kafka,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Platform Team', latency: '2ms', throughput: '50k eps', version: '3.6.0' },
    layer: 3,
  },
  {
    id: 'kafka-market',
    label: 'Market Data Stream',
    serviceType: ServiceType.Kafka,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Data Team', latency: '1ms', throughput: '100k eps', version: '3.6.0' },
    layer: 3,
  },
  {
    id: 'kafka-trades',
    label: 'Trade Events',
    serviceType: ServiceType.Kafka,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Platform Team', latency: '2ms', throughput: '30k eps', version: '3.6.0' },
    layer: 3,
  },
  {
    id: 'kafka-risk',
    label: 'Risk Events',
    serviceType: ServiceType.Kafka,
    environment: Environment.Prod,
    status: ServiceStatus.Warning,
    metadata: { owner: 'Risk Team', latency: '3ms', throughput: '20k eps', version: '3.6.0' },
    layer: 3,
  },
  {
    id: 'kafka-audit',
    label: 'Audit Stream',
    serviceType: ServiceType.Kafka,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Compliance Team', latency: '2ms', throughput: '15k eps', version: '3.6.0' },
    layer: 3,
  },
  {
    id: 'kafka-notifications',
    label: 'Notification Stream',
    serviceType: ServiceType.Kafka,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Platform Team', latency: '2ms', throughput: '10k eps', version: '3.6.0' },
    layer: 3,
  },

  // Layer 4: Batch Processing
  {
    id: 'batch-eod-risk',
    label: 'EOD Risk Batch',
    serviceType: ServiceType.Batch,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Risk Team', latency: '45min', throughput: '2M records', version: '3.0.0' },
    layer: 4,
  },
  {
    id: 'batch-recon',
    label: 'Reconciliation Job',
    serviceType: ServiceType.Batch,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Post-Trade Team', latency: '30min', throughput: '500k records', version: '2.5.0' },
    layer: 4,
  },
  {
    id: 'batch-reports',
    label: 'Report Generator',
    serviceType: ServiceType.Batch,
    environment: Environment.Prod,
    status: ServiceStatus.Warning,
    metadata: { owner: 'Analytics Team', latency: '60min', throughput: '1M records', version: '1.8.0' },
    layer: 4,
  },
  {
    id: 'batch-etl',
    label: 'ETL Pipeline',
    serviceType: ServiceType.Batch,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Data Engineering', latency: '90min', throughput: '5M records', version: '4.2.0' },
    layer: 4,
  },

  // Layer 5: Data Lake / Storage
  {
    id: 'dl-raw',
    label: 'S3 Raw Zone',
    serviceType: ServiceType.DataLake,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Data Engineering', latency: '10ms', throughput: '∞', version: 'N/A' },
    layer: 5,
  },
  {
    id: 'dl-curated',
    label: 'S3 Curated Zone',
    serviceType: ServiceType.DataLake,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Data Engineering', latency: '15ms', throughput: '∞', version: 'N/A' },
    layer: 5,
  },
  {
    id: 'dl-iceberg',
    label: 'Iceberg Tables',
    serviceType: ServiceType.DataLake,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Data Engineering', latency: '50ms', throughput: '10k qps', version: '1.4.0' },
    layer: 5,
  },
  {
    id: 'dl-postgres',
    label: 'PostgreSQL (OLTP)',
    serviceType: ServiceType.DataLake,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'DBA Team', latency: '3ms', throughput: '30k qps', version: '15.2' },
    layer: 5,
  },
  {
    id: 'dl-redis',
    label: 'Redis Cache',
    serviceType: ServiceType.DataLake,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'Platform Team', latency: '<1ms', throughput: '100k qps', version: '7.2' },
    layer: 5,
  },

  // Layer 6: ML / Analytics
  {
    id: 'ml-pricing',
    label: 'Pricing Model',
    serviceType: ServiceType.ML,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'ML Team', latency: '200ms', throughput: '500 rps', version: '2.1.0', port: 7001 },
    layer: 6,
  },
  {
    id: 'ml-risk',
    label: 'Risk Predictor',
    serviceType: ServiceType.ML,
    environment: Environment.Prod,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'ML Team', latency: '350ms', throughput: '300 rps', version: '1.8.0', port: 7002 },
    layer: 6,
  },
  {
    id: 'ml-anomaly',
    label: 'Anomaly Detection',
    serviceType: ServiceType.ML,
    environment: Environment.QA,
    status: ServiceStatus.Warning,
    metadata: { owner: 'ML Team', latency: '500ms', throughput: '200 rps', version: '0.9.5', port: 7003 },
    layer: 6,
  },
  {
    id: 'ml-nlp',
    label: 'NLP Contract Analyzer',
    serviceType: ServiceType.ML,
    environment: Environment.Dev,
    status: ServiceStatus.Healthy,
    metadata: { owner: 'ML Team', latency: '800ms', throughput: '50 rps', version: '0.3.0', port: 7004 },
    layer: 6,
  },
];

// ─── Edges ──────────────────────────────────────────────────────────────────

const edges: ServiceEdge[] = [
  // UI → Gateways
  { id: 'e1', source: 'ui-trading', target: 'gw-main', edgeType: EdgeType.Sync, label: 'REST' },
  { id: 'e2', source: 'ui-trading', target: 'gw-auth', edgeType: EdgeType.Sync, label: 'Auth' },
  { id: 'e3', source: 'ui-risk', target: 'gw-main', edgeType: EdgeType.Sync, label: 'REST' },
  { id: 'e4', source: 'ui-risk', target: 'gw-auth', edgeType: EdgeType.Sync, label: 'Auth' },
  { id: 'e5', source: 'ui-ops', target: 'gw-main', edgeType: EdgeType.Sync, label: 'REST' },
  { id: 'e6', source: 'ui-analytics', target: 'gw-data', edgeType: EdgeType.Sync, label: 'GraphQL' },

  // Gateways → Microservices
  { id: 'e7', source: 'gw-main', target: 'svc-pricing', edgeType: EdgeType.Sync, label: 'gRPC' },
  { id: 'e8', source: 'gw-main', target: 'svc-booking', edgeType: EdgeType.Sync, label: 'gRPC' },
  { id: 'e9', source: 'gw-main', target: 'svc-counterparty', edgeType: EdgeType.Sync, label: 'gRPC' },
  { id: 'e10', source: 'gw-main', target: 'svc-risk-calc', edgeType: EdgeType.Sync, label: 'gRPC' },
  { id: 'e11', source: 'gw-main', target: 'svc-compliance', edgeType: EdgeType.Sync, label: 'REST' },
  { id: 'e12', source: 'gw-main', target: 'svc-settlement', edgeType: EdgeType.Sync, label: 'gRPC' },
  { id: 'e13', source: 'gw-data', target: 'svc-market-data', edgeType: EdgeType.Sync, label: 'REST' },
  { id: 'e14', source: 'gw-main', target: 'svc-notification', edgeType: EdgeType.Sync, label: 'REST' },

  // Microservices → Kafka
  { id: 'e15', source: 'svc-booking', target: 'kafka-orders', edgeType: EdgeType.Async, label: 'Produce' },
  { id: 'e16', source: 'svc-pricing', target: 'kafka-market', edgeType: EdgeType.Async, label: 'Consume' },
  { id: 'e17', source: 'svc-booking', target: 'kafka-trades', edgeType: EdgeType.Async, label: 'Produce' },
  { id: 'e18', source: 'svc-risk-calc', target: 'kafka-risk', edgeType: EdgeType.Async, label: 'Produce' },
  { id: 'e19', source: 'svc-audit', target: 'kafka-audit', edgeType: EdgeType.Async, label: 'Produce' },
  { id: 'e20', source: 'svc-notification', target: 'kafka-notifications', edgeType: EdgeType.Async, label: 'Consume' },
  { id: 'e21', source: 'svc-market-data', target: 'kafka-market', edgeType: EdgeType.Async, label: 'Produce' },
  { id: 'e22', source: 'svc-compliance', target: 'kafka-audit', edgeType: EdgeType.Async, label: 'Produce' },

  // Kafka → Batch
  { id: 'e23', source: 'kafka-risk', target: 'batch-eod-risk', edgeType: EdgeType.Pipeline, label: 'Nightly' },
  { id: 'e24', source: 'kafka-trades', target: 'batch-recon', edgeType: EdgeType.Pipeline, label: 'Hourly' },
  { id: 'e25', source: 'kafka-orders', target: 'batch-reports', edgeType: EdgeType.Pipeline, label: 'Daily' },
  { id: 'e26', source: 'kafka-market', target: 'batch-etl', edgeType: EdgeType.Pipeline, label: 'Continuous' },

  // Batch → Data Lake
  { id: 'e27', source: 'batch-etl', target: 'dl-raw', edgeType: EdgeType.Pipeline, label: 'Ingest' },
  { id: 'e28', source: 'batch-etl', target: 'dl-curated', edgeType: EdgeType.Pipeline, label: 'Transform' },
  { id: 'e29', source: 'batch-eod-risk', target: 'dl-curated', edgeType: EdgeType.Pipeline, label: 'Results' },
  { id: 'e30', source: 'batch-recon', target: 'dl-iceberg', edgeType: EdgeType.Pipeline, label: 'Upsert' },
  { id: 'e31', source: 'batch-reports', target: 'dl-curated', edgeType: EdgeType.Pipeline, label: 'Reports' },

  // Microservices → Data stores
  { id: 'e32', source: 'svc-pricing', target: 'dl-redis', edgeType: EdgeType.Sync, label: 'Cache' },
  { id: 'e33', source: 'svc-booking', target: 'dl-postgres', edgeType: EdgeType.Sync, label: 'CRUD' },
  { id: 'e34', source: 'svc-counterparty', target: 'dl-postgres', edgeType: EdgeType.Sync, label: 'CRUD' },
  { id: 'e35', source: 'svc-risk-calc', target: 'dl-redis', edgeType: EdgeType.Sync, label: 'Cache' },
  { id: 'e36', source: 'svc-compliance', target: 'dl-postgres', edgeType: EdgeType.Sync, label: 'CRUD' },
  { id: 'e37', source: 'svc-settlement', target: 'dl-postgres', edgeType: EdgeType.Sync, label: 'CRUD' },
  { id: 'e38', source: 'svc-audit', target: 'dl-postgres', edgeType: EdgeType.Sync, label: 'Write' },

  // Data Lake → ML
  { id: 'e39', source: 'dl-curated', target: 'ml-pricing', edgeType: EdgeType.Pipeline, label: 'Training' },
  { id: 'e40', source: 'dl-curated', target: 'ml-risk', edgeType: EdgeType.Pipeline, label: 'Training' },
  { id: 'e41', source: 'dl-iceberg', target: 'ml-anomaly', edgeType: EdgeType.Pipeline, label: 'Features' },
  { id: 'e42', source: 'dl-raw', target: 'ml-nlp', edgeType: EdgeType.Pipeline, label: 'Documents' },

  // ML → Microservices (feedback loop)
  { id: 'e43', source: 'ml-pricing', target: 'svc-pricing', edgeType: EdgeType.Sync, label: 'Predictions' },
  { id: 'e44', source: 'ml-risk', target: 'svc-risk-calc', edgeType: EdgeType.Sync, label: 'Scores' },
  { id: 'e45', source: 'ml-anomaly', target: 'kafka-risk', edgeType: EdgeType.Async, label: 'Alerts' },

  // Cross-layer
  { id: 'e46', source: 'svc-risk-calc', target: 'svc-pricing', edgeType: EdgeType.Sync, label: 'Price Feed' },
  { id: 'e47', source: 'svc-booking', target: 'svc-compliance', edgeType: EdgeType.Sync, label: 'Check' },
  { id: 'e48', source: 'svc-booking', target: 'svc-notification', edgeType: EdgeType.Async, label: 'Alert' },
  { id: 'e49', source: 'svc-settlement', target: 'svc-notification', edgeType: EdgeType.Async, label: 'Confirm' },

  // Streaming → ML (real-time inference)
  { id: 'e50', source: 'kafka-market', target: 'ml-pricing', edgeType: EdgeType.Async, label: 'Real-time' },
  { id: 'e51', source: 'kafka-risk', target: 'ml-risk', edgeType: EdgeType.Async, label: 'Real-time' },
];

export const mockGraphData: GraphData = { nodes, edges };

// ─── Style constants ────────────────────────────────────────────────────────

export const SERVICE_TYPE_COLORS: Record<ServiceType, string> = {
  [ServiceType.UI]: '#6366f1',
  [ServiceType.APIGateway]: '#06b6d4',
  [ServiceType.Microservice]: '#8b5cf6',
  [ServiceType.Kafka]: '#f59e0b',
  [ServiceType.Batch]: '#10b981',
  [ServiceType.DataLake]: '#3b82f6',
  [ServiceType.ML]: '#ec4899',
};

export const STATUS_COLORS: Record<ServiceStatus, string> = {
  [ServiceStatus.Healthy]: '#22c55e',
  [ServiceStatus.Warning]: '#f59e0b',
  [ServiceStatus.Down]: '#ef4444',
};

export const LAYER_LABELS: Record<number, string> = {
  0: 'UI Layer',
  1: 'API Gateway',
  2: 'Microservices',
  3: 'Kafka / Streaming',
  4: 'Batch Processing',
  5: 'Data Lake / Storage',
  6: 'ML / Analytics',
};
