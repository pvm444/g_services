import React from 'react';
import {
  ServiceStatus,
} from '../types';
import type { ServiceNode, ServiceEdge } from '../types';
import { SERVICE_TYPE_COLORS, STATUS_COLORS } from '../data/mockData';

interface Props {
  node: ServiceNode | null;
  edges: ServiceEdge[];
  allNodes: ServiceNode[];
  onTraceUpstream: () => void;
  onTraceDownstream: () => void;
  onTraceBoth: () => void;
  onClearHighlight: () => void;
  onClose: () => void;
}

const SidebarPanel: React.FC<Props> = ({
  node,
  edges,
  allNodes,
  onTraceUpstream,
  onTraceDownstream,
  onTraceBoth,
  onClearHighlight,
  onClose,
}) => {
  if (!node) {
    return (
      <div className="sidebar sidebar-empty" id="sidebar-panel">
        <div className="sidebar-placeholder">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#334155" strokeWidth="1.5">
            <circle cx="12" cy="12" r="10" />
            <path d="M12 8v4M12 16h.01" />
          </svg>
          <p>Click a node to view service details</p>
        </div>
      </div>
    );
  }

  const nodeMap = new Map(allNodes.map((n) => [n.id, n]));
  const incoming = edges.filter((e) => e.target === node.id);
  const outgoing = edges.filter((e) => e.source === node.id);

  const statusIcon = (status: ServiceStatus) => {
    const color = STATUS_COLORS[status];
    return (
      <span
        className="status-dot"
        style={{
          backgroundColor: color,
          boxShadow: `0 0 8px ${color}80`,
        }}
      />
    );
  };

  return (
    <div className="sidebar sidebar-active" id="sidebar-panel">
      {/* Header */}
      <div className="sidebar-header">
        <div className="sidebar-title-row">
          <h2 className="sidebar-title">{node.label}</h2>
          <button className="sidebar-close" onClick={onClose} title="Close">
            ×
          </button>
        </div>
        <div className="sidebar-badges">
          <span
            className="badge badge-type"
            style={{ backgroundColor: `${SERVICE_TYPE_COLORS[node.serviceType]}30`, color: SERVICE_TYPE_COLORS[node.serviceType] }}
          >
            {node.serviceType}
          </span>
          <span className="badge badge-env">{node.environment}</span>
          <span className="badge badge-status">
            {statusIcon(node.status)} {node.status}
          </span>
        </div>
      </div>

      {/* Metadata */}
      <div className="sidebar-section">
        <h3 className="section-title">Metadata</h3>
        <div className="metadata-grid">
          <div className="meta-item">
            <span className="meta-label">Owner</span>
            <span className="meta-value">{node.metadata.owner}</span>
          </div>
          <div className="meta-item">
            <span className="meta-label">Latency</span>
            <span className="meta-value">{node.metadata.latency}</span>
          </div>
          <div className="meta-item">
            <span className="meta-label">Throughput</span>
            <span className="meta-value">{node.metadata.throughput}</span>
          </div>
          {node.metadata.version && (
            <div className="meta-item">
              <span className="meta-label">Version</span>
              <span className="meta-value">v{node.metadata.version}</span>
            </div>
          )}
          {node.metadata.port && (
            <div className="meta-item">
              <span className="meta-label">Port</span>
              <span className="meta-value">:{node.metadata.port}</span>
            </div>
          )}
        </div>
      </div>

      {/* Path Tracing */}
      <div className="sidebar-section">
        <h3 className="section-title">Path Tracing</h3>
        <div className="trace-buttons">
          <button className="trace-btn" id="btn-trace-upstream" onClick={onTraceUpstream}>
            ↑ Upstream
          </button>
          <button className="trace-btn" id="btn-trace-downstream" onClick={onTraceDownstream}>
            ↓ Downstream
          </button>
          <button className="trace-btn" id="btn-trace-both" onClick={onTraceBoth}>
            ↕ Both
          </button>
          <button className="trace-btn trace-btn-clear" id="btn-clear-highlight" onClick={onClearHighlight}>
            Clear
          </button>
        </div>
      </div>

      {/* Incoming Dependencies */}
      <div className="sidebar-section">
        <h3 className="section-title">
          Incoming <span className="dep-count">{incoming.length}</span>
        </h3>
        <ul className="dep-list">
          {incoming.map((e) => {
            const src = nodeMap.get(e.source);
            return (
              <li key={e.id} className="dep-item">
                <span
                  className="dep-dot"
                  style={{ backgroundColor: src ? SERVICE_TYPE_COLORS[src.serviceType] : '#475569' }}
                />
                <span className="dep-name">{src?.label ?? e.source}</span>
                <span className="dep-edge-type">{e.edgeType}</span>
              </li>
            );
          })}
          {incoming.length === 0 && <li className="dep-empty">No incoming dependencies</li>}
        </ul>
      </div>

      {/* Outgoing Dependencies */}
      <div className="sidebar-section">
        <h3 className="section-title">
          Outgoing <span className="dep-count">{outgoing.length}</span>
        </h3>
        <ul className="dep-list">
          {outgoing.map((e) => {
            const tgt = nodeMap.get(e.target);
            return (
              <li key={e.id} className="dep-item">
                <span
                  className="dep-dot"
                  style={{ backgroundColor: tgt ? SERVICE_TYPE_COLORS[tgt.serviceType] : '#475569' }}
                />
                <span className="dep-name">{tgt?.label ?? e.target}</span>
                <span className="dep-edge-type">{e.edgeType}</span>
              </li>
            );
          })}
          {outgoing.length === 0 && <li className="dep-empty">No outgoing dependencies</li>}
        </ul>
      </div>
    </div>
  );
};

export default SidebarPanel;
