import React from 'react';
import {
  SERVICE_TYPE_COLORS,
  STATUS_COLORS,
  LAYER_LABELS,
} from '../data/mockData';

interface Props {
  visibleLayers: Set<number>;
  onToggleLayer: (layer: number) => void;
}

const RightPanel: React.FC<Props> = ({ visibleLayers, onToggleLayer }) => {
  return (
    <div className="right-panel" id="right-panel">
      {/* Node Legend */}
      <div className="legend-section">
        <h3 className="legend-title">Service Types</h3>
        <ul className="legend-list">
          {Object.entries(SERVICE_TYPE_COLORS).map(([type, color]) => (
            <li key={type} className="legend-item">
              <span className="legend-swatch" style={{ backgroundColor: color }} />
              <span className="legend-label">{type}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Status Legend */}
      <div className="legend-section">
        <h3 className="legend-title">Status</h3>
        <ul className="legend-list">
          {Object.entries(STATUS_COLORS).map(([status, color]) => (
            <li key={status} className="legend-item">
              <span
                className="legend-swatch legend-swatch-glow"
                style={{ backgroundColor: color, boxShadow: `0 0 6px ${color}80` }}
              />
              <span className="legend-label">{status}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Edge Legend */}
      <div className="legend-section">
        <h3 className="legend-title">Edge Types</h3>
        <ul className="legend-list">
          <li className="legend-item">
            <span className="legend-line legend-line-solid" />
            <span className="legend-label">Sync (REST/gRPC)</span>
          </li>
          <li className="legend-item">
            <span className="legend-line legend-line-dotted" />
            <span className="legend-label">Async (Events)</span>
          </li>
          <li className="legend-item">
            <span className="legend-line legend-line-dashed" />
            <span className="legend-label">Pipeline (Batch)</span>
          </li>
        </ul>
      </div>

      {/* Layer Toggles */}
      <div className="legend-section">
        <h3 className="legend-title">Layers</h3>
        <ul className="legend-list">
          {Object.entries(LAYER_LABELS).map(([layerStr, label]) => {
            const layer = Number(layerStr);
            const isVisible = visibleLayers.has(layer);
            return (
              <li key={layer} className="legend-item legend-toggle">
                <label className="layer-toggle" htmlFor={`layer-${layer}`}>
                  <input
                    type="checkbox"
                    id={`layer-${layer}`}
                    checked={isVisible}
                    onChange={() => onToggleLayer(layer)}
                    className="layer-checkbox"
                  />
                  <span className="layer-toggle-track">
                    <span className="layer-toggle-thumb" />
                  </span>
                  <span className="legend-label">{label}</span>
                </label>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
};

export default RightPanel;
