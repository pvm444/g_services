import React from 'react';
import {
  ServiceType,
  Environment,
  ServiceStatus,
} from '../types';
import type { FilterState, LayoutName } from '../types';

interface Props {
  filters: FilterState;
  layout: LayoutName;
  onFiltersChange: (f: FilterState) => void;
  onLayoutChange: (l: LayoutName) => void;
  onFit: () => void;
  onExportPng: () => void;
  onExportJson: () => void;
}

const layouts: { label: string; value: LayoutName }[] = [
  { label: 'Hierarchical', value: 'dagre' },
  { label: 'Force-Directed', value: 'cola' },
  { label: 'Concentric', value: 'concentric' },
  { label: 'Grid', value: 'grid' },
  { label: 'Circle', value: 'circle' },
];

const TopToolbar: React.FC<Props> = ({
  filters,
  layout,
  onFiltersChange,
  onLayoutChange,
  onFit,
  onExportPng,
  onExportJson,
}) => {
  const update = (partial: Partial<FilterState>) =>
    onFiltersChange({ ...filters, ...partial });

  return (
    <div className="toolbar" id="top-toolbar">
      {/* Brand */}
      <div className="toolbar-brand">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" stroke="#6366f1" strokeWidth="2" />
          <circle cx="12" cy="8" r="2" fill="#6366f1" />
          <circle cx="7" cy="15" r="2" fill="#06b6d4" />
          <circle cx="17" cy="15" r="2" fill="#ec4899" />
          <line x1="12" y1="10" x2="7" y2="13" stroke="#475569" strokeWidth="1" />
          <line x1="12" y1="10" x2="17" y2="13" stroke="#475569" strokeWidth="1" />
          <line x1="7" y1="15" x2="17" y2="15" stroke="#475569" strokeWidth="1" />
        </svg>
        <span className="toolbar-title">CDM Service Graph</span>
      </div>

      {/* Search */}
      <div className="toolbar-section">
        <div className="search-box" id="search-box">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2">
            <circle cx="11" cy="11" r="8" />
            <path d="M21 21l-4.35-4.35" />
          </svg>
          <input
            type="text"
            placeholder="Search services…"
            value={filters.search}
            onChange={(e) => update({ search: e.target.value })}
            id="search-input"
          />
        </div>
      </div>

      {/* Filters */}
      <div className="toolbar-section">
        <select
          className="filter-select"
          id="filter-type"
          value={filters.serviceType}
          onChange={(e) =>
            update({ serviceType: e.target.value as ServiceType | 'all' })
          }
        >
          <option value="all">All Types</option>
          {Object.values(ServiceType).map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>

        <select
          className="filter-select"
          id="filter-env"
          value={filters.environment}
          onChange={(e) =>
            update({ environment: e.target.value as Environment | 'all' })
          }
        >
          <option value="all">All Envs</option>
          {Object.values(Environment).map((e) => (
            <option key={e} value={e}>
              {e}
            </option>
          ))}
        </select>

        <select
          className="filter-select"
          id="filter-status"
          value={filters.status}
          onChange={(e) =>
            update({ status: e.target.value as ServiceStatus | 'all' })
          }
        >
          <option value="all">All Status</option>
          {Object.values(ServiceStatus).map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {/* Layout */}
      <div className="toolbar-section">
        <div className="layout-switcher" id="layout-switcher">
          {layouts.map((l) => (
            <button
              key={l.value}
              className={`layout-btn ${layout === l.value ? 'active' : ''}`}
              onClick={() => onLayoutChange(l.value)}
              title={l.label}
            >
              {l.label}
            </button>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="toolbar-section toolbar-actions">
        <button className="action-btn" id="btn-fit" onClick={onFit} title="Fit to Screen">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" />
          </svg>
        </button>
        <button className="action-btn" id="btn-export-png" onClick={onExportPng} title="Export PNG">
          PNG
        </button>
        <button className="action-btn" id="btn-export-json" onClick={onExportJson} title="Export JSON">
          JSON
        </button>
      </div>
    </div>
  );
};

export default TopToolbar;
