import {
  useRef,
  useEffect,
  useImperativeHandle,
  forwardRef,
  useCallback,
} from 'react';
import cytoscape from 'cytoscape';
import type { Core, EventObject, NodeSingular } from 'cytoscape';
import cola from 'cytoscape-cola';
import dagre from 'cytoscape-dagre';
import { EdgeType } from '../types';
import type { GraphData, FilterState, LayoutName, ServiceNode } from '../types';
import { SERVICE_TYPE_COLORS, STATUS_COLORS } from '../data/mockData';

// Register layout extensions once
cytoscape.use(cola);
cytoscape.use(dagre);

export interface CytoscapeGraphHandle {
  fit: () => void;
  exportPng: () => Promise<Blob | null>;
  exportJson: () => string;
  highlightPath: (nodeId: string, direction: 'upstream' | 'downstream' | 'both') => void;
  clearHighlight: () => void;
}

interface Props {
  data: GraphData;
  layout: LayoutName;
  filters: FilterState;
  onNodeSelect: (node: ServiceNode | null) => void;
}



// eslint-disable-next-line @typescript-eslint/no-explicit-any
const cytoscapeStylesheet: any[] = [
  // ── Base node ──
  {
    selector: 'node',
    style: {
      label: 'data(label)',
      'text-valign': 'bottom',
      'text-halign': 'center',
      'font-size': '11px',
      'font-family': "'Inter', sans-serif",
      'font-weight': 500,
      color: '#e2e8f0',
      'text-margin-y': 8,
      'text-outline-color': '#0f172a',
      'text-outline-width': 2,
      width: 52,
      height: 52,
      'background-opacity': 0.95,
      'border-width': 3,
      'overlay-padding': 6,
      'transition-property': 'border-color, border-width, opacity, background-color',
      'transition-duration': 200,
    } as any,
  },
  // ── Node type colors (applied via data attributes) ──
  ...Object.entries(SERVICE_TYPE_COLORS).map(([type, color]) => ({
    selector: `node[serviceType = "${type}"]`,
    style: {
      'background-color': color,
      'border-color': color,
    },
  })),
  // ── Status glow ──
  ...Object.entries(STATUS_COLORS).map(([status, color]) => ({
    selector: `node[status = "${status}"]`,
    style: {
      'border-color': color,
      'border-width': status === 'Down' ? 4 : 3,
    } as any,
  })),
  // ── Edges ──
  {
    selector: 'edge',
    style: {
      width: 1.8,
      'line-color': '#475569',
      'target-arrow-color': '#475569',
      'target-arrow-shape': 'triangle',
      'arrow-scale': 0.8,
      'curve-style': 'bezier',
      label: 'data(label)',
      'font-size': '9px',
      'font-family': "'Inter', sans-serif",
      color: '#94a3b8',
      'text-outline-color': '#0f172a',
      'text-outline-width': 1.5,
      'text-rotation': 'autorotate',
      'transition-property': 'line-color, target-arrow-color, opacity, width',
      'transition-duration': 200,
    } as any,
  },
  {
    selector: `edge[edgeType = "${EdgeType.Async}"]`,
    style: { 'line-style': 'dotted', 'line-dash-pattern': [6, 3] } as any,
  },
  {
    selector: `edge[edgeType = "${EdgeType.Pipeline}"]`,
    style: { 'line-style': 'dashed', 'line-dash-pattern': [10, 5] } as any,
  },
  // ── Highlighted (selected path) ──
  {
    selector: '.highlighted',
    style: {
      'border-width': 5,
      'z-index': 10,
      opacity: 1,
    } as any,
  },
  {
    selector: 'edge.highlighted',
    style: {
      width: 3,
      'line-color': '#facc15',
      'target-arrow-color': '#facc15',
      'z-index': 10,
      opacity: 1,
    } as any,
  },
  // ── Faded ──
  {
    selector: '.faded',
    style: { opacity: 0.15 } as any,
  },
  // ── Selected node ──
  {
    selector: 'node:selected',
    style: {
      'border-width': 5,
      'border-color': '#facc15',
    } as any,
  },
];

function getLayoutOptions(name: LayoutName): cytoscape.LayoutOptions {
  switch (name) {
    case 'dagre':
      return {
        name: 'dagre',
        rankDir: 'TB',
        nodeSep: 60,
        rankSep: 100,
        padding: 40,
        animate: true,
        animationDuration: 400,
      } as any;
    case 'cola':
      return {
        name: 'cola',
        nodeSpacing: 50,
        edgeLengthVal: 120,
        animate: true,
        maxSimulationTime: 2000,
        padding: 40,
      } as any;
    case 'grid':
      return {
        name: 'grid',
        rows: 6,
        padding: 40,
        animate: true,
        animationDuration: 400,
      };
    case 'circle':
      return {
        name: 'circle',
        padding: 40,
        animate: true,
        animationDuration: 400,
      };
    case 'concentric':
      return {
        name: 'concentric',
        padding: 40,
        animate: true,
        animationDuration: 400,
        concentric: (node: any) => 6 - (node.data('layer') as number),
        levelWidth: () => 1,
      } as any;
    default:
      return { name: 'dagre' } as any;
  }
}

const CytoscapeGraph = forwardRef<CytoscapeGraphHandle, Props>(
  ({ data, layout, filters, onNodeSelect }, ref) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const cyRef = useRef<Core | null>(null);

    // Initialize Cytoscape
    useEffect(() => {
      if (!containerRef.current) return;

      const cy = cytoscape({
        container: containerRef.current,
        style: cytoscapeStylesheet,
        minZoom: 0.2,
        maxZoom: 3,
        wheelSensitivity: 0.3,
      });

      cyRef.current = cy;

      // Click handler
      cy.on('tap', 'node', (evt: EventObject) => {
        const node = evt.target as NodeSingular;
        const nodeData = node.data() as ServiceNode;
        onNodeSelect(nodeData);

        // Auto-highlight connected nodes (both upstream and downstream)
        cy.elements().removeClass('highlighted faded').addClass('faded');
        node.removeClass('faded').addClass('highlighted');
        
        const connected = node.predecessors().union(node.successors());
        connected.removeClass('faded').addClass('highlighted');
      });

      cy.on('tap', (evt: EventObject) => {
        if (evt.target === cy) {
          onNodeSelect(null);
          cy.elements().removeClass('highlighted faded');
        }
      });

      return () => {
        cy.destroy();
        cyRef.current = null;
      };
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // Update elements when data or filters change
    useEffect(() => {
      const cy = cyRef.current;
      if (!cy) return;

      cy.batch(() => {
        cy.elements().remove();

        // Filter nodes
        const filteredNodes = data.nodes.filter((n) => {
          if (!filters.visibleLayers.has(n.layer)) return false;
          if (filters.serviceType !== 'all' && n.serviceType !== filters.serviceType)
            return false;
          if (filters.environment !== 'all' && n.environment !== filters.environment)
            return false;
          if (filters.status !== 'all' && n.status !== filters.status) return false;
          if (
            filters.search &&
            !n.label.toLowerCase().includes(filters.search.toLowerCase()) &&
            !n.id.toLowerCase().includes(filters.search.toLowerCase())
          )
            return false;
          return true;
        });

        const nodeIds = new Set(filteredNodes.map((n) => n.id));

        // Add nodes
        filteredNodes.forEach((n) => {
          cy.add({
            group: 'nodes',
            data: { ...n },
          });
        });

        // Add edges (only if both endpoints visible)
        data.edges.forEach((e) => {
          if (nodeIds.has(e.source) && nodeIds.has(e.target)) {
            cy.add({
              group: 'edges',
              data: { ...e },
            });
          }
        });
      });

      // Run layout
      cy.layout(getLayoutOptions(layout)).run();

      // Fit after layout
      setTimeout(() => cy.fit(undefined, 40), 500);
    }, [data, filters, layout]);

    // Imperative handle
    const highlightPath = useCallback(
      (nodeId: string, direction: 'upstream' | 'downstream' | 'both') => {
        const cy = cyRef.current;
        if (!cy) return;

        cy.elements().addClass('faded');

        const node = cy.getElementById(nodeId);
        node.removeClass('faded').addClass('highlighted');

        let connected = cy.collection();
        if (direction === 'upstream' || direction === 'both') {
          connected = connected.union(node.predecessors());
        }
        if (direction === 'downstream' || direction === 'both') {
          connected = connected.union(node.successors());
        }

        connected.removeClass('faded').addClass('highlighted');
      },
      []
    );

    const clearHighlight = useCallback(() => {
      cyRef.current?.elements().removeClass('highlighted faded');
    }, []);

    useImperativeHandle(
      ref,
      () => ({
        fit: () => cyRef.current?.fit(undefined, 40),
        exportPng: async () => {
          const cy = cyRef.current;
          if (!cy) return null;
          const dataUrl = cy.png({
            output: 'blob',
            bg: '#0f172a',
            scale: 2,
            full: true,
          });
          return dataUrl as unknown as Blob;
        },
        exportJson: () => {
          const cy = cyRef.current;
          if (!cy) return '{}';
          return JSON.stringify(cy.json(), null, 2);
        },
        highlightPath,
        clearHighlight,
      }),
      [highlightPath, clearHighlight]
    );

    return (
      <div
        ref={containerRef}
        style={{ width: '100%', height: '100%', background: '#0f172a' }}
      />
    );
  }
);

CytoscapeGraph.displayName = 'CytoscapeGraph';

export default CytoscapeGraph;
