import React, { useRef, useState, useCallback, useEffect } from 'react';
import { saveAs } from 'file-saver';
import CytoscapeGraph from './components/CytoscapeGraph';
import type { CytoscapeGraphHandle } from './components/CytoscapeGraph';
import TopToolbar from './components/TopToolbar';
import SidebarPanel from './components/SidebarPanel';
import RightPanel from './components/RightPanel';
import { mockGraphData } from './data/mockData';
import { ServiceStatus } from './types';
import type { ServiceNode, FilterState, LayoutName, GraphData } from './types';

const ALL_LAYERS = new Set([0, 1, 2, 3, 4, 5, 6]);

const defaultFilters: FilterState = {
  search: '',
  serviceType: 'all',
  environment: 'all',
  status: 'all',
  visibleLayers: new Set(ALL_LAYERS),
};

const App: React.FC = () => {
  const graphRef = useRef<CytoscapeGraphHandle>(null);
  const [selectedNode, setSelectedNode] = useState<ServiceNode | null>(null);
  const [filters, setFilters] = useState<FilterState>(defaultFilters);
  const [layout, setLayout] = useState<LayoutName>('dagre');
  const [graphData, setGraphData] = useState<GraphData>(mockGraphData);
  const [statusBarText, setStatusBarText] = useState('Ready');

  // ── Mock real-time status updates ────────────────────────────────────────
  useEffect(() => {
    const interval = setInterval(() => {
      setGraphData((prev) => {
        const nodes = prev.nodes.map((n) => {
          if (Math.random() > 0.92) {
            const statuses = [ServiceStatus.Healthy, ServiceStatus.Warning, ServiceStatus.Down];
            const newStatus = statuses[Math.floor(Math.random() * statuses.length)];
            return { ...n, status: newStatus };
          }
          return n;
        });
        return { ...prev, nodes };
      });
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  // ── Node selection ───────────────────────────────────────────────────────
  const handleNodeSelect = useCallback((node: ServiceNode | null) => {
    setSelectedNode(node);
    if (node) {
      setStatusBarText(`Selected: ${node.label}`);
    } else {
      setStatusBarText('Ready');
    }
  }, []);

  // ── Layer toggle ─────────────────────────────────────────────────────────
  const handleToggleLayer = useCallback((layer: number) => {
    setFilters((prev) => {
      const next = new Set(prev.visibleLayers);
      if (next.has(layer)) {
        next.delete(layer);
      } else {
        next.add(layer);
      }
      return { ...prev, visibleLayers: next };
    });
  }, []);

  // ── Export ───────────────────────────────────────────────────────────────
  const handleExportPng = useCallback(async () => {
    const blob = await graphRef.current?.exportPng();
    if (blob) {
      saveAs(blob, 'service-graph.png');
      setStatusBarText('Exported as PNG');
    }
  }, []);

  const handleExportJson = useCallback(() => {
    const json = graphRef.current?.exportJson();
    if (json) {
      const blob = new Blob([json], { type: 'application/json' });
      saveAs(blob, 'service-graph.json');
      setStatusBarText('Exported as JSON');
    }
  }, []);

  // ── Path tracing ─────────────────────────────────────────────────────────
  const handleTraceUpstream = useCallback(() => {
    if (selectedNode) graphRef.current?.highlightPath(selectedNode.id, 'upstream');
  }, [selectedNode]);

  const handleTraceDownstream = useCallback(() => {
    if (selectedNode) graphRef.current?.highlightPath(selectedNode.id, 'downstream');
  }, [selectedNode]);

  const handleTraceBoth = useCallback(() => {
    if (selectedNode) graphRef.current?.highlightPath(selectedNode.id, 'both');
  }, [selectedNode]);

  const handleClearHighlight = useCallback(() => {
    graphRef.current?.clearHighlight();
  }, []);

  const handleClose = useCallback(() => {
    setSelectedNode(null);
    graphRef.current?.clearHighlight();
    setStatusBarText('Ready');
  }, []);

  // ── Stats ────────────────────────────────────────────────────────────────
  const healthyCount = graphData.nodes.filter((n) => n.status === ServiceStatus.Healthy).length;
  const warningCount = graphData.nodes.filter((n) => n.status === ServiceStatus.Warning).length;
  const downCount = graphData.nodes.filter((n) => n.status === ServiceStatus.Down).length;

  return (
    <div className="app-root" id="app-root">
      <TopToolbar
        filters={filters}
        layout={layout}
        onFiltersChange={setFilters}
        onLayoutChange={setLayout}
        onFit={() => graphRef.current?.fit()}
        onExportPng={handleExportPng}
        onExportJson={handleExportJson}
      />

      <div className="main-content">
        <SidebarPanel
          node={selectedNode}
          edges={graphData.edges}
          allNodes={graphData.nodes}
          onTraceUpstream={handleTraceUpstream}
          onTraceDownstream={handleTraceDownstream}
          onTraceBoth={handleTraceBoth}
          onClearHighlight={handleClearHighlight}
          onClose={handleClose}
        />

        <div className="graph-container" id="graph-container">
          <CytoscapeGraph
            ref={graphRef}
            data={graphData}
            layout={layout}
            filters={filters}
            onNodeSelect={handleNodeSelect}
          />
        </div>

        <RightPanel
          visibleLayers={filters.visibleLayers}
          onToggleLayer={handleToggleLayer}
        />
      </div>

      {/* Status Bar */}
      <div className="status-bar" id="status-bar">
        <span className="status-text">{statusBarText}</span>
        <div className="status-stats">
          <span className="stat stat-healthy">
            <span className="stat-dot stat-dot-healthy" />
            {healthyCount} healthy
          </span>
          <span className="stat stat-warning">
            <span className="stat-dot stat-dot-warning" />
            {warningCount} warning
          </span>
          <span className="stat stat-down">
            <span className="stat-dot stat-dot-down" />
            {downCount} down
          </span>
          <span className="stat stat-total">
            {graphData.nodes.length} services · {graphData.edges.length} connections
          </span>
        </div>
      </div>
    </div>
  );
};

export default App;
