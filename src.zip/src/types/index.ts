// ─── Service Types ──────────────────────────────────────────────────────────

export enum ServiceType {
  UI = 'UI',
  APIGateway = 'API Gateway',
  Microservice = 'Microservice',
  Kafka = 'Kafka/Stream',
  Batch = 'Batch',
  DataLake = 'Data Lake',
  ML = 'ML/Analytics',
}

export enum Environment {
  Prod = 'Prod',
  QA = 'QA',
  Dev = 'Dev',
}

export enum ServiceStatus {
  Healthy = 'Healthy',
  Warning = 'Warning',
  Down = 'Down',
}

export enum EdgeType {
  Sync = 'sync',
  Async = 'async',
  Pipeline = 'pipeline',
}

export interface ServiceMetadata {
  owner: string;
  latency: string;
  throughput: string;
  version?: string;
  port?: number;
}

export interface ServiceNode {
  id: string;
  label: string;
  serviceType: ServiceType;
  environment: Environment;
  status: ServiceStatus;
  metadata: ServiceMetadata;
  layer: number; // 0=UI, 1=Gateway, 2=Microservice, 3=Kafka, 4=Batch, 5=DataLake, 6=ML
}

export interface ServiceEdge {
  id: string;
  source: string;
  target: string;
  edgeType: EdgeType;
  label?: string;
}

export interface GraphData {
  nodes: ServiceNode[];
  edges: ServiceEdge[];
}

export interface FilterState {
  search: string;
  serviceType: ServiceType | 'all';
  environment: Environment | 'all';
  status: ServiceStatus | 'all';
  visibleLayers: Set<number>;
}

export type LayoutName = 'cola' | 'dagre' | 'grid' | 'circle' | 'concentric';
