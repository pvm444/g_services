declare module 'cytoscape-cola' {
  const ext: cytoscape.Ext;
  export default ext;
}

declare module 'cytoscape-dagre' {
  const ext: cytoscape.Ext;
  export default ext;
}
